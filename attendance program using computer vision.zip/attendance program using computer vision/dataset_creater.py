import cv2
import numpy as np
import sqlite3
faceDetect=cv2.CascadeClassifier(r"C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\haarcascade_frontalface_default.xml")

cam=cv2.VideoCapture(r"C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\#0 Python for Beginners ｜ Programming Tutorial.mp4")

def insertorupdate(id,name,age):
    con=sqlite3.connect('information.db')
    c=con.cursor()
    cmd='SELECT * FROM STUDENTS WHERE ID=?'
    c.execute(cmd,(id,))
    
    recordexists=False

    for row in c.fetchone():
        recordexists=True
    
    if (recordexists):
        c.execute('UPDATE STUDENTS SET NAME=? WHERE ID=?',(name,id,))
        c.execute('UPDATE STUDENTS SET AGE=? WHERE ID=?',(age,id,))
    else:
        c.execute('INSERT INTO STUDENTS (ID,NAME,AGE) VALUES (?,?,?)',(id,name,age))
    
    con.commit()
    con.commit()

id=input('enter your id')
name=input('enter your name')
age=input('enter your age')

insertorupdate(id,name,age)

#detect face in webcam

samplephoto_count=0
while True:
    success,img=cam.read()
    gray=cv2.cvtColor(img,cv2.COLOR_RGB2GRAY)
    faces=faceDetect.detectMultiScale(gray,1.3,5)

    for (x,y,w,h) in faces:
        samplephoto_count+=1

        cv2.imwrite(r'C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\sample_photos\user.'+str(id)+'.'+str(samplephoto_count)+'.jpg',gray[y:y+h,x:x+w])

        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
        cv2.waitKey(100)
    cv2.imshow(f'Face{samplephoto_count}',img)
    cv2.waitKey(1)
    if (samplephoto_count>20):
        break;
