import sqlite3

con=sqlite3.connect('information.db')

c=con.cursor()

c.execute('CREATE TABLE IF NOT EXISTS STUDENTS(ID INTEGER PRIMARY KEY, NAME TEXT, AGE INTEGER)')

con.commit()
c.execute('INSERT INTO STUDENTS(ID,NAME,AGE) VALUES (1,"TOXIC",20)')

con.commit()
con.close()
