import os
import cv2
import numpy as np
from PIL import Image

# pip uninstall opencv-python
# pip install opencv-contrib-python==4.5.5.64

recognizer=cv2.face.LBPHFaceRecognizer_create()

def get_emages_with_id(path):
    images_path=[os.path.join(path,f) for f in os.listdir(path)]
    faces=[]
    ids=[]
    for single_image_path in images_path:
        faceimg=Image.open(single_image_path).convert('L')
        faceNp=np.array(faceimg,np.uint8)
        id=int(os.path.split(single_image_path)[-1].split('.')[1])
        print(id)
        faces.append(faceNp)
        ids.append(id)
        cv2.imshow('image',faceNp)
        cv2.waitKey(0)
    
    return faces,np.array(ids)

path=r'C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\sample_photos'

faces,ids=get_emages_with_id(path)
recognizer.train(faces,ids)
recognizer.save(r'C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\facerecognizer.yml')
cv2.destroyAllWindows()
