import cv2
import numpy as np
import os
import sqlite3

facedetect=cv2.CascadeClassifier(r"C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\haarcascade_frontalface_default.xml")
cam=cv2.VideoCapture(r"C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\#0 Python for Beginners ｜ Programming Tutorial.mp4")
recognizer=cv2.face.LBPHFaceRecognizer_create()

recognizer.read(r'C:\Users\thenn\OneDrive\thenn\OneDrive\Desktop\attendance program using computer vision\facerecognizer.yml')

def getprofile(id):
    con=sqlite3.connect('information.db')
    c=con.cursor()
    c.execute("SELECT * FROM STUDENTS WHERE ID=?",(id,))
    profile=None
    for row in c.fetchall():
        profile=row
    
    con.close()
    return profile

while (True):
    suc,img=cam.read()
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    faces=facedetect.detectMultiScale(gray,1.3,5)
    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),((x+w),(y+h)),(0,255,0),3)
        id,conf=recognizer.predict(gray[y:y+h,x:x+w])
        profile=getprofile(id)

        if profile!=None:
            cv2.putText(img,'name:'+ str(profile[1]),(x,y+h+20),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,127),2)
            cv2.putText(img,'id:'+ str(id),(x,y+h+100),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,127),2)
    cv2.imshow('Face',img)
    if (cv2.waitKey(1)==ord('q')):
        break;
cam.release
cv2.destroyAllWindows()